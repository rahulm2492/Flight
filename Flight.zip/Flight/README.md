# WeatherAPI
This is the DEMO Weather Forecast App.

Responsive and Voice controlled Weather Forecast App.

So , Now you can Get Weather Forecast By using your VOICE also. Try "Weather For ${City}" or only ${City}.       
Since voice mode is availabel only on few browsers now , so it is available in DEV mode only.

Steps to Develope and Contribute :           
npm install                                                       
npm run dev for Developement Mode providing sytatic sugar for Hot Module Reloading.                                       
npm run tdd for running unit test while developing module.                                                         
npm run test for unit testing.
npm run build for making build and deploy.

This app is hosted on heroku.com               
Prdocution URL : http://weather-forbuildit.herokuapp.com/       
DEV URL : http://weatherbuild.herokuapp.com/

Catch is Please use http instead of https , since open weather api serves content over http.                                          
TODO :

       1) Responsive , so that we can easily access over any device.                                                                  
       2) Search using Speak  , yeah Speech Recognition.                                                                                   
       3) Accuracy using algorithims.
