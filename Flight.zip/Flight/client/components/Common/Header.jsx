import React from 'react';


class Header extends React.Component {
  constructor(props){
    super(props);
  }
 

  render() {
       return (
        <h3 >Flight Search Engine</h3>
       );
  }
}



export default Header;