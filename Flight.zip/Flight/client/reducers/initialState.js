export default {
    departureCity:'',
    arrivalCity:'',
    departureDate:'',
    returnDate:'',
    passengers:'',
    tabSelected:'oneWay',
    submitClicked:false,
    leftRange:0,
    rightRange:10000
}